﻿using System.Collections.Generic;
using System.Diagnostics;
using System.Timers;

namespace SampleCaliburnWPF.Watcher;

public class ProcessWatcher
{
    private string DEVICE_MANAGER = "DeviceManager";
    private string DEVICE_MANAGER_PATH = @"C:\\RepositoryCore\\Infrastructure\\Common\\Bin\\Debug\\DeviceManager.exe";

    private string CONFIGURATION_SERVICE = "@C:\\RepositoryCore\\Infrastructure\\Common\\Bin\\Debug\\ConfigurationService.exe";
    private string CONFIGURATION_SERVICE_PATH = "ConfigurationService";

    private string DIAGNOSTICS_SERVICE = "DiagnosticsService";
    private string DIAGNOSTICS_SERVICE_PATH = @"C:\\RepositoryCore\\Infrastructure\\Common\\Bin\\Debug\\DiagnosticsService.exe";

    private string JOBS_SERVICE = "JobsService";
    private string JOBS_SERVICE_PATH = @"C:\\RepositoryCore\\Infrastructure\\Common\\Bin\\Debug\\JobsService.exe";

    private string IMAGE_PROCESS_PROVIDER_SERVICE = "ImageProcessProviderService";
    private string IMAGE_PROCESS_PROVIDER_SERVICE_PATH = @"C:\\RepositoryCore\\Infrastructure\\Common\\Bin\\Debug\ImageProcessProviderService.exe";

    public Dictionary<string, ProcessData> Processes;

    public ProcessWatcher()
    {
        Processes = new Dictionary<string, ProcessData>();

        Process process1 = new Process();
        process1.StartInfo.FileName = DEVICE_MANAGER_PATH;
        Processes.Add(DEVICE_MANAGER, new ProcessData(process1, DEVICE_MANAGER));

        Process process2 = new Process();
        process2.StartInfo.FileName = CONFIGURATION_SERVICE_PATH;
        Processes.Add(CONFIGURATION_SERVICE, new ProcessData(process2, CONFIGURATION_SERVICE));

        Process process3 = new Process();
        process3.StartInfo.FileName = DIAGNOSTICS_SERVICE_PATH;
        Processes.Add(DIAGNOSTICS_SERVICE, new ProcessData(process3, DIAGNOSTICS_SERVICE));

        Process process4 = new Process();
        process4.StartInfo.FileName = JOBS_SERVICE_PATH;
        Processes.Add(JOBS_SERVICE, new ProcessData(process4, JOBS_SERVICE));
        
        Process process5 = new Process();
        process5.StartInfo.FileName = IMAGE_PROCESS_PROVIDER_SERVICE_PATH;
        Processes.Add(IMAGE_PROCESS_PROVIDER_SERVICE, new ProcessData(process5, IMAGE_PROCESS_PROVIDER_SERVICE));


        Process[] currentProcesses = Process.GetProcesses();

        foreach (Process process in currentProcesses)
        {
            if (process.ProcessName == DEVICE_MANAGER)
            {
                if (Processes.TryGetValue(DEVICE_MANAGER, out ProcessData processData))
                    processData.IsRunning = true;
            }

            if (process.ProcessName == CONFIGURATION_SERVICE)
            {
                if (Processes.TryGetValue(CONFIGURATION_SERVICE, out ProcessData processData))
                    processData.IsRunning = true;
            }

            if (process.ProcessName == DIAGNOSTICS_SERVICE)
            {
                if (Processes.TryGetValue(DIAGNOSTICS_SERVICE, out ProcessData processData))
                    processData.IsRunning = true;
            }

            if (process.ProcessName == JOBS_SERVICE)
            {
                if (Processes.TryGetValue(JOBS_SERVICE, out ProcessData processData))
                    processData.IsRunning = true;
            }

            if (process.ProcessName == IMAGE_PROCESS_PROVIDER_SERVICE)
            {
                if (Processes.TryGetValue(IMAGE_PROCESS_PROVIDER_SERVICE, out ProcessData processData))
                    processData.IsRunning = true;
            }

            Timer timer = new Timer();
            timer.Interval = 5000; 
            timer.Elapsed += TimerElapsed;
            timer.Start();
        }
    }

    private void TimerElapsed(object? sender, ElapsedEventArgs e)
    {
        Process[] currentProcesses = Process.GetProcesses();
        if (IsProcessRunning(currentProcesses, DEVICE_MANAGER))
        {

        }
        //Process[] currentProcesses = Process.GetProcesses();

        //// Check for new processes
        //foreach (Process process in currentProcesses)
        //{
        //    if (!IsProcessRunning(previousProcesses, process))
        //    {
        //        OnProcessStarted(process);
        //    }
        //}

        //// Check for exited processes
        //foreach (Process process in previousProcesses)
        //{
        //    if (!IsProcessRunning(currentProcesses, process))
        //    {
        //        OnProcessExited(process);
        //    }
        //}
    }

    private bool IsProcessRunning(Process[] processes, string processName)
    {
        foreach (Process process in processes)
        {
            if (process.ProcessName == processName)
            {
                if (Processes.TryGetValue(processName, out ProcessData processData))
                {
                    processData.IsRunning = true;
                    return true;
                }
            }
        }
        if (Processes.TryGetValue(processName, out ProcessData procData))
        {
            procData.IsRunning = false;
        }
        return false;
    }

    public void RunProcess(ProcessData processData)
    {
        processData.Process.Start();
        processData.Process.WaitForExit();
        if(Processes.TryGetValue(processData.ProcessName, out ProcessData data))
        {
            data.IsRunning = true;
        }
    }

    public void StopProcess(ProcessData process)
    {
        if (Processes.TryGetValue(process.ProcessName, out ProcessData data))
        {
            data.IsRunning = false;
        }
    }
}