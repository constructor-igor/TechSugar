def get_start_version():
	return "level-start-version: 1.0"